# golang-webapp

This is the source code for the [Write a Web App in Go](https://www.youtube.com/playlist?list=PLmxT2pVYo5LDMV0epL4z4CUbxvIw6umg_) video series.
